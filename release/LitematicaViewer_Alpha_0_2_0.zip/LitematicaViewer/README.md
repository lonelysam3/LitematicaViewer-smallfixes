LitematicaViewer
==================
### Minecraft tool - A tool make easy to check litematica files 让我的世界投影查看更加的轻量便捷
A light Viewer of Litematica files
`imput file` Input your file first and choose mode for check your file.
choose `Analysis file` or `Simple Analysis`.
* `Analysis file` used for check your block's properties and block ID
* `Simple Analysis` used for easy check your block' numbers and names, no properties
Under bottom has the size of the litermatica file.

一个轻量便捷的投影查看器
* `导入` 导入投影文件
* 选择分析模式：
* `分析` 高级分析，带方块属性和完整方块ID
* `简洁分析` 轻量分析，只会显示方块名与数量
下面显示投影建筑体积

> **Warning:** cause of technique isses cannot upload file with entities inside. 因为技术原因无法导入含实体的投影文件.
